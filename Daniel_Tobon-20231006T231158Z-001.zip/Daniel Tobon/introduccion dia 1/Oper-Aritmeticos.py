# Operadores aritmeticos 

#Suma 
num1 = 5 
num2 = 2 

suma = num1 + num2 
print("suma:" ,suma)

#Resta

resta = num1 - num2 
print("Resta:" ,resta)

#Multiplicacion 

Multiplicacion = num1 - num2 
print("Multiplicacion:" ,Multiplicacion)


#Division real 

print(num1 / num1) 

#Division entera 
print(num1 // num1) 

#Modulo
modulo = num1 % num2 
print("Modulo:" , modulo)

#Potencia 
print(num1 ** num2) 

print( 5 % 13) 

print(5 + 2 * 3 ** 2 % 5)