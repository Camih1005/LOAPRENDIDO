# 1 type() retorna el tipo de dato de la variable

# Entero
edad = 25 
print( "edad:", type(edad))  # 1

# String
nombre = "Daniel" 
print( "nombre:", type(nombre))  

# Tipo Float 
temp = 33.5 
print( "temperatura", type(temp)) 

# Tipo logico 
soltero = True # False
print("soltero:" , type(soltero)) 

