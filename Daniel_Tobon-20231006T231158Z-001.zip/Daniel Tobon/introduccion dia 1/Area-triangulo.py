#Calcular el area de un triangulo 
base = float(input("Digite la base del triangulo:")) 
altura = float(input("Digite la altura del triangulo:")) 

area = (base * altura) / 2 

print("El area del triangulo es: " , area)